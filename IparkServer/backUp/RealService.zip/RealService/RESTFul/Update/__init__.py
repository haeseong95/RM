from .UpdateNickname import *
from .UpdatePasswd import *